// Circle data and initialization
const circlesData = [
    { id: 1, name: "Limbo" },
    { id: 2, name: "Lust" },
    { id: 3, name: "Gluttony" },
    { id: 4, name: "Greed" },
    { id: 5, name: "Wrath & Sloth" },
    { id: 6, name: "Heresy" },
    { id: 7, name: "Violence" },
    { id: 8, name: "Fraud" },
    { id: 9, name: "Treachery" }
];

document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('circlesContainer');
    const modal = document.getElementById('imageModal');
    const modalImage = document.getElementById('modalImage');
    const modalTitle = document.getElementById('modalTitle');
    const modalText = document.getElementById('modalText');
    const closeBtn = document.querySelector('.close');

    // Create circles
    circlesData.forEach(circle => {
        const circleElement = document.createElement('div');
        circleElement.className = 'circle';
        const img = document.createElement('img');
        img.src = circle.id === 8 ? 'assets/this.jpeg' : `assets/${circle.id}.jpeg`;
        img.className = 'circle-image';
        img.onerror = function() {
            this.onerror = null;
            this.src = 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100"><rect width="100" height="100" fill="#8B0000"/><text x="50" y="50" font-family="MedievalSharp" font-size="10" fill="#FFD700" text-anchor="middle" dominant-baseline="middle">'+circle.id+'</text></svg>';
        };
        
        const span = document.createElement('span');
        span.style.fontFamily = 'MedievalSharp';
        span.textContent = circle.name;
        
        circleElement.appendChild(img);
        circleElement.appendChild(span);
        
        circleElement.addEventListener('click', () => {
            modalImage.src = circle.id === 8 ? 'assets/this.jpeg' : `assets/${circle.id}.jpeg`;
            modalImage.style.display = 'block';
            modalImage.style.objectFit = circle.id === 8 ? 'cover' : 'contain';
            modalImage.onerror = function() {
                this.src = 'data:image/svg+xml;utf8,<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"600\" height=\"600\" viewBox=\"0 0 600 600\"><rect width=\"600\" height=\"600\" fill=\"%238B0000\"/><text x=\"300\" y=\"300\" font-family=\"Arial\" font-size=\"24\" fill=\"%23FFD700\" text-anchor=\"middle\" dominant-baseline=\"middle\">${circle.name} Image</text></svg>';
                modalTitle.textContent = `${circle.name}`;
            };
            modalTitle.textContent = circle.id === 5 ? "Wrath & Sloth" : circle.name;
            const modalText = document.getElementById('modalText');
            if (circle.id === 8) {
                modalText.style.overflowY = 'auto';
                modalText.style.maxHeight = '200px';
            } else {
                modalText.style.overflowY = 'visible';
                modalText.style.maxHeight = 'none';
            }
            
            if (circle.id === 1) { // Limbo
                modalText.textContent = "Sin: Unbaptized souls and virtuous non-Christians.\nPunishment: Eternal separation from God but no physical suffering.";
                modalText.style.display = 'block';
            } else {
                modalText.style.display = 'none';
            }
            modal.style.display = 'block';
        });

        container.appendChild(circleElement);
    });

    // Modal close functionality
    closeBtn.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });
});
